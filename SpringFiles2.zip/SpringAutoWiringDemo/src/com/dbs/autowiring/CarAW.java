package com.dbs.autowiring;

public class CarAW {
	CarAW car;

	public CarAW getCar() {
		return car;
	}

	public void setCar(CarAW car) {
		this.car = car;
	}
	
}
