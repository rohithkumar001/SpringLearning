package com.dbs.dao;

import java.util.List;

import com.dbs.model.EmployeeVO;

public interface EmployeeDAO {
	public List<EmployeeVO> getAllEmployees();
}
