package com.example.RohithSpringBoot.Repository;

import com.example.RohithSpringBoot.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface CustomerRepository extends JpaRepository<Customer,Long> {
    @Modifying
    @Query(value = "select * from customer WHERE customer.name=:name",nativeQuery = true)
    public List<Customer> getbyName(String name);

    @Modifying
    @Query(value = "select * from customer WHERE customer.bankname=:bankname", nativeQuery = true)
    public List<Customer> getbyBankName(String bankname);
}
