package com.example.RohithSpringBoot.Controller;

import com.example.RohithSpringBoot.Repository.CustomerRepository;
import com.example.RohithSpringBoot.Service.CustomerService;
import com.example.RohithSpringBoot.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/customer")
public class CustomerController {
    @Autowired
    private CustomerService customerService;
    @Autowired
    private CustomerRepository customerRepository;
    @PostMapping("/save")
    public Customer save( @RequestBody Customer customer){
      return  customerService.saveCustomer(customer);
    }
    @GetMapping("/showall")
    public List<Customer> rohith(){
        return customerService.showall();
    }
    @DeleteMapping("/deletebyid")
    public String delete( @RequestParam(name="id") Long id){
        customerService.deleteybId(id);
        return "Deleted Successfully";
    }
    @GetMapping("/findbyid")
    public Customer find(@RequestParam(name="id") Long id){
        return customerService.findbyId(id);
    }
    @PatchMapping("/updatename")
    public String update(@RequestParam(name="id") Long id,@RequestBody Customer customer){
        customerService.updatebyId(id,customer);
        return "Updated Successfully";
    }
    @GetMapping("/getbyname")
    public List<Customer> getbyName(@RequestParam(name="name") String name){
      return  customerRepository.getbyName(name);
    }
    @GetMapping("/getbybankname")
    public List<Customer> getbyBankName(@RequestParam(name="bankname") String bankname){
        return customerRepository.getbyBankName(bankname);
    }
}
