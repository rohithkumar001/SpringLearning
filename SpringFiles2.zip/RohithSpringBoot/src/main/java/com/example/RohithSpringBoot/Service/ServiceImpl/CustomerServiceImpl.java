package com.example.RohithSpringBoot.Service.ServiceImpl;

import com.example.RohithSpringBoot.Repository.CustomerRepository;
import com.example.RohithSpringBoot.Service.CustomerService;
import com.example.RohithSpringBoot.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public Customer saveCustomer(Customer customer) {
        return customerRepository.save(customer);

    }

    @Override
    public List<Customer> showall() {
        return customerRepository.findAll();
    }

    @Override
    public void deleteybId(Long id) {
        customerRepository.deleteById(id);

    }

    @Override
    public Customer findbyId(Long id) {
        return customerRepository.findById(id).orElseThrow(()->new RuntimeException("Failed"));
    }

    @Override
    public String updatebyId(Long id, Customer customer) {
        Customer c = customerRepository.findById(id).get();
        c.setName(customer.getName());
        customerRepository.save(c);
        return "Updated Successfully";
    }

}
