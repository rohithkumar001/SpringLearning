package in.is.pma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbsProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbsProjectApplication.class, args);
	}

}
