package com.example.RohithSpringBoot.Exception;

public class ResourceNotFound extends Throwable{
    public String ResourceNotFound(){
        return "Resource Not Found";
    }
}
