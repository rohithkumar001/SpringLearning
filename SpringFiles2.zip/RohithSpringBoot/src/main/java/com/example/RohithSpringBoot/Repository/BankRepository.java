package com.example.RohithSpringBoot.Repository;

import com.example.RohithSpringBoot.model.Bank;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BankRepository extends JpaRepository<Bank,String> {

}
