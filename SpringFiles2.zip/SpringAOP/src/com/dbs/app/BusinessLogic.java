package com.dbs.app;

public class BusinessLogic {
	public void getBusinessLogic() {
		System.out.println("***************************");
		
		System.out.println("Inside Business Logic Method");
		
		System.out.println("***************************");
	}
}
