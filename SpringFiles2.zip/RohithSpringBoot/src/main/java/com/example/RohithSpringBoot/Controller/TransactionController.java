package com.example.RohithSpringBoot.Controller;

import com.example.RohithSpringBoot.Service.TransactionService;
import com.example.RohithSpringBoot.model.Transaction;
import com.example.RohithSpringBoot.model.TransactionDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/transaction")
public class TransactionController {
    @Autowired
    private TransactionService transactionService;
    @PostMapping("/make")
    public Transaction make(@RequestBody TransactionDTO transactionDTO){
        return transactionService.saveTransaction(transactionDTO);
    }
}
