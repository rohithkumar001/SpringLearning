package com.example.RohithSpringBoot.Service.ServiceImpl;

import com.example.RohithSpringBoot.Repository.BankRepository;
import com.example.RohithSpringBoot.Service.BankService;
import com.example.RohithSpringBoot.model.Bank;
import org.springframework.beans.factory.annotation.Autowired;

public class BankServiceImpl implements BankService {
    @Autowired
    private BankRepository bankRepository;

    @Override
    public Bank saveBank(Bank bank) {
        return bankRepository.save(bank);
    }

    @Override
    public Bank findbyId(String id) {
        return bankRepository.findById(id).orElseThrow(()->new RuntimeException("Failed to find"));
    }
}
