package in.is.pma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbsProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
