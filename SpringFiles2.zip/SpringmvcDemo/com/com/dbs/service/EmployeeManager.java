package com.dbs.service;

import java.util.List;

import com.dbs.model.EmployeeVO;

public interface EmployeeManager {

	public List<EmployeeVO> getAllEmployees();
	

}
