package com.dbs.mappingdemo.model;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class MappingMain {

	public static void main(String[] args) {
<<<<<<< HEAD
		// TODO Auto-generated method stub
		User user = new User();
		User user2 = new User();
		
		user.setUserName("sunil");
		user2.setUserName("Anand");
		
=======
		
		
		//Lets Create Users
		User user = new User();
		User user2 = new User();
		
		user2.setUserName("Sunil");
		user.setUserName("Hafeez");
		
		//Lets create Address
>>>>>>> e004f2e (more spring files)
		Address address = new Address();
		address.setStreet("Gachibowli");
		address.setCity("Hyderabad");
		
<<<<<<< HEAD
		Address address2= new Address();
		address2.setStreet("Hitec city");
		address2.setCity("Hyderabad");
		
		Vehicle car= new Vehicle();
		car.setName("audi");
		
		Vehicle jeep= new Vehicle();
		jeep.setName("Compass");
		
		Vehicle bike = new Vehicle();
		bike.setName("Hayabusa");
=======
		Address address2 = new Address();
		address2.setStreet("Hightech City");
		address2.setCity("Secundrabad");
		
		
		//Lets add vehicles
		Vehicle car = new Vehicle();
		car.setName("Audi");
		
		Vehicle jeep = new Vehicle();
		jeep.setName("Compass");
		
		Vehicle bike = new Vehicle();
		bike.setName("Harley Davidson");
>>>>>>> e004f2e (more spring files)
		
		Vehicle cycle = new Vehicle();
		cycle.setName("KTM");
		
<<<<<<< HEAD
		Mobile sony=new Mobile();
=======
		//now lets instantiate mobiles
		Mobile sony = new Mobile();
>>>>>>> e004f2e (more spring files)
		sony.setBrand("Sony");
		sony.setModel("Xperia Z3");
		
		Mobile iphone = new Mobile();
<<<<<<< HEAD
		iphone.setBrand("apple");
		iphone.setModel("Iphone 13 pro max");
		
		Mobile oneplus = new Mobile();
		oneplus.setBrand("oneplus");
		oneplus.setModel("Oneplus 10pro");
		
		Mobile nothing = new Mobile();
		nothing.setBrand("Nothing");
		nothing.setModel("Phone 1");
		
=======
		iphone.setBrand("Apple");
		iphone.setModel("iphone 13");
		
		Mobile oneplus = new Mobile();
		oneplus.setBrand("Oneplus");
		oneplus.setModel("One Plus 10");
		
		Mobile nothing = new Mobile();
		nothing.setBrand("Nothing");
		nothing.setModel("Nothing mobile");
		
		//lets use associations by setters
>>>>>>> e004f2e (more spring files)
		user.setAddress(address);
		user2.setAddress(address2);
		address.setUser(user);
		address2.setUser(user2);
		
		user.getMobile().add(sony);
		user2.getMobile().add(iphone);
<<<<<<< HEAD
		sony.getUser().add(user);
		iphone.getUser().add(user2);
=======
		sony.setUser(user);
		iphone.setUser(user2);
>>>>>>> e004f2e (more spring files)
		
		user.getVehicle().add(car);
		user2.getVehicle().add(bike);
		car.getUser().add(user);
		bike.getUser().add(user2);
		
		user.getVehicle().add(jeep);
		jeep.getUser().add(user);
		user2.getVehicle().add(cycle);
		cycle.getUser().add(user2);
		
<<<<<<< HEAD
		//lets add data to database
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session session=sf.openSession();
=======
		//Lets add the data to database
		SessionFactory sf = new Configuration().configure().buildSessionFactory();
		Session session = sf.openSession();
>>>>>>> e004f2e (more spring files)
		session.beginTransaction();
		session.save(user);
		session.save(user2);
		session.getTransaction().commit();
		session.close();
<<<<<<< HEAD
=======
		

>>>>>>> e004f2e (more spring files)
	}

}
