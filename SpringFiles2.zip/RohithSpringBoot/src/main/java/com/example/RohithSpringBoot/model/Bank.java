package com.example.RohithSpringBoot.model;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bank")
@Data
public class Bank {
    @Id
    private String bic;
    private String bankname;
}
