package com.dbs.dbsdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbsdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
