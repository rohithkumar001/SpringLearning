package com.example.RohithSpringBoot.Service;

import com.example.RohithSpringBoot.model.Bank;

public interface BankService {
    public Bank saveBank(Bank bank);
    public Bank findbyId(String id);
}
