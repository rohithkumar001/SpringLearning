package com.example.RohithSpringBoot.Service.ServiceImpl;

import com.example.RohithSpringBoot.Repository.BankRepository;
import com.example.RohithSpringBoot.Repository.CustomerRepository;
import com.example.RohithSpringBoot.Repository.TransactionRepository;
import com.example.RohithSpringBoot.Service.TransactionService;
import com.example.RohithSpringBoot.model.Bank;
import com.example.RohithSpringBoot.model.Customer;
import com.example.RohithSpringBoot.model.Transaction;
import com.example.RohithSpringBoot.model.TransactionDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TransactionServiceImpl implements TransactionService {
    @Autowired
    private TransactionRepository transactionRepository;


    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private BankRepository bankRepository;

    @Override
    public Transaction saveTransaction(TransactionDTO transactionDTO) {
        //return transactionRepository.save(transactionDTO);
        Customer c = customerRepository.findById(transactionDTO.custid).get();
        Bank b = bankRepository.findById(transactionDTO.bic).get();
        //Transaction ts=transactionRepository.findById(transactionDT).get();
        Customer c1 = customerRepository.findById(transactionDTO.custid2).get();
        Bank b1 = bankRepository.findById(transactionDTO.bic2).get();
        Transaction t= new Transaction();
        t.setCustomer(c);
        t.setBank(b);
        t.setAmount(transactionDTO.getAmount());
        c.setBal(c.getBal()-transactionDTO.getAmount());
        c1.setBal(c1.getBal()+transactionDTO.getAmount());

        return transactionRepository.save(t);

    }
}
