package com.example.RohithSpringBoot.model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "customer")
@Data
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long custid;
    private String name;
    private Double bal;
    private String bankname;

}
