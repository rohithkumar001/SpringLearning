package com.example.RohithSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RohithSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
