package com.example.RohithSpringBoot.Service;

import com.example.RohithSpringBoot.model.Customer;

import java.util.List;

public interface CustomerService {
    public Customer saveCustomer(Customer customer);
    public List<Customer> showall();
    public void deleteybId(Long id);
    public Customer findbyId(Long id);
    public String updatebyId(Long id,Customer customer);


}
