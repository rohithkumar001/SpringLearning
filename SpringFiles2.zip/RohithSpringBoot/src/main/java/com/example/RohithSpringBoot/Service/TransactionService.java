package com.example.RohithSpringBoot.Service;

import com.example.RohithSpringBoot.Repository.TransactionRepository;
import com.example.RohithSpringBoot.model.Transaction;
import com.example.RohithSpringBoot.model.TransactionDTO;

public interface TransactionService  {
    public Transaction saveTransaction(TransactionDTO transactionDTO);
}
