package com.example.RohithSpringBoot.model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name="transaction")
@Data
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @ManyToOne
    @JoinColumn(name = "customer_custid",referencedColumnName = "custid")
    private Customer customer;
    @ManyToOne
    @JoinColumn(name = "bank_bic",referencedColumnName = "bic")
    private Bank bank;

    private Double amount;

}
