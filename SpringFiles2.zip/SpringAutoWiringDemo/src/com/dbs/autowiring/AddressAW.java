package com.dbs.autowiring;

public class AddressAW {
	
}
